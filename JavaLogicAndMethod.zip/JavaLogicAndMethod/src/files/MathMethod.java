package files;

public class MathMethod {
    public static void main(String[] args) {
        System.out.println("Math Method Java");
        System.out.println(Math.max(5, 10));
        System.out.println(Math.min(5, 10));
        System.out.println(Math.sqrt(81));
        System.out.println(Math.abs(-2));
        System.out.println(Math.sqrt(81));
        System.out.println(Math.random());
        int randomNum = (int)(Math.random() * 101);
        System.out.println(randomNum);
    }
}
